package task1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Task1 {

    static char vowels[] = {'a', 'A', 'e', 'E', 'i', 'I', 'o', 'O', 'u', 'U', 'y', 'Y'};
    static char consonants[] = {'b', 'B', 'c', 'C', 'd', 'D', 'f', 'F', 'g', 'G', 'h', 'H', 'j', 'J', 'k', 'K', 'l', 'L', 'm', 'M', 'n', 'N', 'p', 'P', 'q', 'Q', 'r', 'R', 's', 'S', 't', 'T', 'v', 'V', 'w', 'W', 'x', 'X', 'z', 'Z'};

    public static void main(String[] args) {
        // TODO code application logic here
        try {
            FileReader reader = new FileReader("datafile.txt");
            BufferedReader br = new BufferedReader(reader);
            BufferedWriter bw = new BufferedWriter(new FileWriter("results.txt"));
            StringBuilder sb = new StringBuilder();
            String s = "";
            while ((s = br.readLine()) != null) {
                String[] str = s.split(" ");
                String replace = Decode(str);
                sb.append(replace).append("\n");
            }
            System.out.println(sb);
            bw.write(sb.toString());
            reader.close();
            bw.close();
            br.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public static String Decode(String[] str) {
        if (str.length == 0) {
            return "";
        }
        StringBuilder ans = new StringBuilder();
        for (String s : str) {
            char current = '%';
            for (int i = 0; i < s.length(); i++) {
                if (s.charAt(i) == 'C' || s.charAt(i) == 'V') {
                    current = s.charAt(i);
                    String number = "";
                    i++;
                    while (i < s.length() && (s.charAt(i) != 'C' && s.charAt(i) != 'V')) {
                        number += s.charAt(i);
                        i++;
                    }
                    char corresponding = find(current, number);
                    ans.append(corresponding);
                    i--;
                }
            }
            ans.append(" ");
        }
        return ans.toString();
    }

    public static char find(char current, String number) {
        int index = Integer.parseInt(number);
        if (current == 'V') {
            return vowels[index - 1];
        }
        return consonants[index - 1];
    }
}
